# 音程听辨（Android）

简体中文、离线运行、无广告、无追踪的 Android 音程听辨应用。页面资源内置于 APK，由本机 WebView 加载；音频由设备本地合成。

## 隐私设计

- AndroidManifest 未声明 `INTERNET` 权限。
- 不包含广告 SDK、统计 SDK、账号或服务器请求。
- 页面不加载外部资源；声音由本机实时生成。
- MIT License，见 `LICENSE`。

## 最简单的 APK 构建方式（云端）

项目带有 GitHub Actions 工作流：`.github/workflows/build-apk.yml`。推送到 `main` 或 `master` 分支后会自动构建；也可以在 GitHub 仓库的 **Actions → Build Android APK → Run workflow** 手动触发。

构建成功后：

1. 打开仓库的 **Actions** 标签页。
2. 进入最新一次成功的 **Build Android APK** 运行记录。
3. 在页面底部的 **Artifacts** 区域下载 `interval-ear-trainer-debug-apk`。
4. 解压下载的 ZIP，得到 `app-debug.apk`，将它传到安卓手机并点击安装。

注意：GitHub Actions 产物会保留 14 天。此工作流生成的是 debug APK，适合个人测试安装，不是用于 Google Play 发布的正式签名版本。

## 本地构建

需要 JDK 17、Android SDK API 35 和 Gradle 8.9：

```bash
gradle --no-daemon assembleDebug
```

APK 输出路径：`app/build/outputs/apk/debug/app-debug.apk`。

## 验证状态

网页原型已通过基本 JavaScript 功能测试；此项目仍需要通过 GitHub Actions 实际编译，并在目标安卓手机上验证音频和界面。编译成功不等于已经完成真机测试。
